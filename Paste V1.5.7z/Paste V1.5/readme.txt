1) First, please put program folder in your final location
2) Please uninstall old version if it exist
3) Install using .application file or setup, launch using .application file
